import React, { useEffect, useState } from "react";
import AppLayout from "@/layouts/app-layout";
import { Head, usePage, router } from "@inertiajs/react";
import { Box, Layers, Users, BookOpen, TrendingUp, AlertTriangle, CheckCircle2, Clock, ShieldCheck, X, Calendar, Timer, XCircle, UserCheck, UserX, ClipboardCheck, Activity, Monitor, Smartphone, Globe, Shield, Eye, LogIn, LogOut, BarChart3, UserCog, Crown, Download } from "lucide-react";
import {
  PieChart,
  Pie,
  Cell,
  ResponsiveContainer,
  Tooltip,
  Legend,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
} from "recharts";
import { motion, AnimatePresence } from "framer-motion";
import CountUp from "react-countup";

const COLORS = ["#DC2626", "#F59E0B", "#22C55E"];

// Card statistik atas yang lebih hidup dan elegan
const InfoCard = ({
  title,
  value,
  icon: Icon,
  onClick,
}: {
  title: string;
  value: number;
  icon: React.ElementType;
  onClick?: () => void;
}) => (
  <motion.div
    onClick={onClick}
    whileHover={{ scale: 1.02, y: -2 }}
    whileTap={{ scale: 0.98 }}
    className={`bg-white p-5 sm:p-6 rounded-3xl shadow-xs border border-gray-100/80 flex items-center gap-4 transition-all duration-300 group ${
      onClick ? "cursor-pointer hover:shadow-md hover:border-[#8B5E3C]/30" : ""
    }`}
  >
    <div className="w-12 h-12 sm:w-14 sm:h-14 bg-gradient-to-br from-[#8B5E3C] to-[#6F4E37] rounded-2xl flex items-center justify-center text-white shadow-md shadow-[#8B5E3C]/20 flex-shrink-0 group-hover:scale-105 transition-transform">
      <Icon className="w-6 h-6 sm:w-7 sm:h-7" />
    </div>
    <div className="min-w-0">
      <p className="text-xs sm:text-sm text-gray-400 font-bold uppercase tracking-wider">{title}</p>
      <p className="text-2xl sm:text-3xl font-black text-gray-800 mt-0.5">
        <CountUp end={value} duration={1.2} />
      </p>
    </div>
  </motion.div>
);

export default function Dashboard() {
  const {
    totalItem = 0,
    totalResep = 0,
    totalKategori = 0,
    totalUser = 0,
    izinRevisiPending = [],
    stokHampirHabis = 0,
    stokHabis = 0,
    staffSudahInput = [],
    staffBelumInput = [],
    totalStaff = 0,
    ownerData,
    todayStockReport,
    stokAman = 0,
    stokDate,
    isStokFromPreviousDay = false,
    auth,
  } = usePage<any>().props;

  const isOwner = auth?.user?.role === 'owner';

  const [showPilihStok, setShowPilihStok] = useState(false);
  const [showFormRevisi, setShowFormRevisi] = useState(false);
  const [selectedIzin, setSelectedIzin] = useState<any>(null);
  const [showActivityDetail, setShowActivityDetail] = useState(false);
  const [selectedDayActivity, setSelectedDayActivity] = useState<any>(null);
  const [showExecSummaryDetail, setShowExecSummaryDetail] = useState(false);
  const [execDetailTab, setExecDetailTab] = useState<'activity' | 'login'>('activity');

  // State untuk modal detail card executive
  const [showWeeklyActivityDetail, setShowWeeklyActivityDetail] = useState(false);
  const [showWeeklyLoginDetail, setShowWeeklyLoginDetail] = useState(false);
  const [showSupervisorDetail, setShowSupervisorDetail] = useState(false);
  const [showIzinProcessedDetail, setShowIzinProcessedDetail] = useState(false);

  const [formRevisi, setFormRevisi] = useState({
    tanggalMulai: "",
    jamMulai: "",
    tanggalSelesai: "",
    jamSelesai: "",
  });

  // Data untuk pie chart dengan 3 kategori (menggunakan data dari backend)
  const totalStokHarian = (stokHabis || 0) + (stokHampirHabis || 0) + (stokAman || 0);

  const pieData = [
    { name: "Stok Habis", value: stokHabis || 0 },
    { name: "Hampir Habis", value: stokHampirHabis || 0 },
    { name: "Stok Aman", value: stokAman },
  ];

  const handlePieClick = () => {
    // 🔥 UBAH INI: Jangan setShowPilihStok, tapi buka modal detail item
    setShowItemDetailModal(true);

    // Opsional: Reset tab ke "Stok Habis" saat dibuka
    setSelectedDetailCategory('habis');
  };

const { itemDetails } = usePage<any>().props; // Tangkap data dari controller
const [showItemDetailModal, setShowItemDetailModal] = useState(false);
const [selectedDetailCategory, setSelectedDetailCategory] = useState<'habis' | 'hampir' | 'aman'>('habis');

  // --- FUNGSI UPDATE IZIN ---
  const submitIzinRevisi = (id: number, action: 'approve' | 'reject', extraData: any = {}) => {
    router.post(route('izin-revisi.update', id), { action, ...extraData }, {
        onSuccess: () => {
            setShowFormRevisi(false);
            setFormRevisi({ tanggalMulai: "", jamMulai: "", tanggalSelesai: "", jamSelesai: "" });
        },
        onError: (err) => {
            console.error(err);
            alert("Terjadi kesalahan, coba lagi.");
        }
    });
  };

  return (
    <AppLayout header={<h2 className="text-lg sm:text-xl md:text-2xl font-bold text-gray-800">Dashboard</h2>}>
      <Head title="Dashboard" />

      <div className="space-y-4 sm:space-y-6 md:space-y-8 pb-6 sm:pb-8 md:pb-10">
        {/* Grid card: Simple dan formal dengan warna sama - RESPONSIVE */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4 md:gap-6">
          <InfoCard
            title="Total Item"
            value={totalItem}
            icon={Layers}
            onClick={() => router.visit("/item")}
          />

          <InfoCard
            title="Total Resep"
            value={totalResep}
            icon={BookOpen}
            onClick={() => router.visit("/resep")}
          />

          <InfoCard
            title="Total Kategori"
            value={totalKategori}
            icon={Box}
            onClick={() => router.visit("/kategori")}
          />

          <InfoCard
            title="Total User"
            value={totalUser}
            icon={Users}
            onClick={() => router.visit("/manajemen-akun")}
          />
        </div>

        {/* Status Stok Harian dengan 3 kategori - RESPONSIVE */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          whileHover={{ scale: 1.01, y: -2 }}
          whileTap={{ scale: 0.99 }}
          transition={{ duration: 0.3 }}
          onClick={handlePieClick}
          className="bg-[#F2ECE4] p-5 sm:p-6 md:p-7 rounded-3xl shadow-xs cursor-pointer hover:shadow-md hover:border-[#8B5E3C]/40 transition-all duration-300 border border-amber-200/60"
        >
          <div className="flex items-center justify-between mb-4 sm:mb-6">
            <div>
              <h3 className="text-base sm:text-lg font-bold text-gray-800 flex items-center gap-2">
                <TrendingUp className="w-4 h-4 sm:w-5 sm:h-5 text-[#8B5E3C]" />
                Status Stok Harian
              </h3>
              <p className="text-xs sm:text-sm text-gray-500 mt-1">
                {isStokFromPreviousDay
                  ? `Data terakhir: ${new Date(stokDate + 'T00:00:00').toLocaleDateString('id-ID', { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' })} (belum ada input hari ini)`
                  : 'Klik untuk melihat detail stok'}
              </p>
            </div>
          </div>

          <div className="flex flex-col md:flex-row items-center gap-4 sm:gap-6 md:gap-8">
            <div className="relative min-w-0 min-h-[180px] w-full md:w-1/2 h-[180px] sm:h-[200px] md:h-[220px]">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={pieData}
                    dataKey="value"
                    nameKey="name"
                    cx="50%"
                    cy="50%"
                    innerRadius={50}
                    outerRadius={75}
                    paddingAngle={3}
                    stroke="none"
                  >
                    {pieData.map((entry, index) => (
                      <Cell key={index} fill={COLORS[index % COLORS.length]} />
                    ))}
                  </Pie>
                  <Tooltip
                    contentStyle={{
                      backgroundColor: '#fff',
                      border: 'none',
                      borderRadius: '12px',
                      boxShadow: '0 4px 20px rgba(0,0,0,0.1)'
                    }}
                  />
                </PieChart>
              </ResponsiveContainer>
              {/* Center text */}
              <div className="absolute inset-0 flex flex-col items-center justify-center pointer-events-none">
                <span className="text-2xl sm:text-3xl font-bold text-gray-800">{totalStokHarian}</span>
                <span className="text-xs text-gray-500">Total Stok</span>
              </div>
            </div>

            {/* Legend kustom dengan 3 kategori - RESPONSIVE */}
            <div className="w-full md:w-1/2 space-y-2 sm:space-y-3">
              <div className="flex items-center justify-between p-3 sm:p-4 bg-red-50 rounded-lg sm:rounded-xl border border-red-100">
                <div className="flex items-center gap-2 sm:gap-3">
                  <div className="w-3 h-3 sm:w-4 sm:h-4 rounded-full bg-red-500 flex-shrink-0" />
                  <div>
                    <span className="font-medium text-gray-700 text-sm sm:text-base">Stok Habis</span>
                    <p className="text-xs text-gray-500 hidden sm:block">Stok = 0</p>
                  </div>
                </div>
                <span className="text-xl sm:text-2xl font-bold text-red-600">{stokHabis || 0}</span>
              </div>
              <div className="flex items-center justify-between p-3 sm:p-4 bg-amber-50 rounded-lg sm:rounded-xl border border-amber-100">
                <div className="flex items-center gap-2 sm:gap-3">
                  <div className="w-3 h-3 sm:w-4 sm:h-4 rounded-full bg-amber-500 flex-shrink-0" />
                  <div>
                    <span className="font-medium text-gray-700 text-sm sm:text-base">Hampir Habis</span>
                    <p className="text-xs text-gray-500 hidden sm:block">Stok 1-7</p>
                  </div>
                </div>
                <span className="text-xl sm:text-2xl font-bold text-amber-600">{stokHampirHabis || 0}</span>
              </div>
              <div className="flex items-center justify-between p-3 sm:p-4 bg-green-50 rounded-lg sm:rounded-xl border border-green-100">
                <div className="flex items-center gap-2 sm:gap-3">
                  <div className="w-3 h-3 sm:w-4 sm:h-4 rounded-full bg-green-500 flex-shrink-0" />
                  <div>
                    <span className="font-medium text-gray-700 text-sm sm:text-base">Stok Aman</span>
                    <p className="text-xs text-gray-500 hidden sm:block">Stok &gt; 7</p>
                  </div>
                </div>
                <span className="text-xl sm:text-2xl font-bold text-green-600">{stokAman}</span>
              </div>
            </div>
          </div>
        </motion.div>

        {/* List Permintaan Izin Revisi - RESPONSIVE */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          whileHover={{ scale: 1.01, y: -2 }}
          transition={{ duration: 0.3 }}
          className="bg-[#F2ECE4] p-5 sm:p-6 md:p-7 rounded-3xl shadow-xs border border-amber-200/60 hover:shadow-md hover:border-[#8B5E3C]/40 transition-all duration-300"
        >
          <div className="flex items-center justify-between mb-4 sm:mb-6">
            <h3 className="text-base sm:text-lg font-bold text-gray-800 flex items-center gap-2.5">
              <div className="w-8 h-8 rounded-xl bg-[#8B5E3C]/10 flex items-center justify-center text-[#8B5E3C]">
                <ShieldCheck className="w-4 h-4 sm:w-5 sm:h-5" />
              </div>
              <span className="hidden sm:inline">Permintaan Izin Revisi</span>
              <span className="sm:hidden">Izin Revisi</span>
            </h3>
            {izinRevisiPending.length > 0 && (
              <span className="px-3 py-1 bg-amber-500 text-white text-xs font-bold rounded-full shadow-xs animate-pulse">
                {izinRevisiPending.length} Menunggu Persetujuan
              </span>
            )}
          </div>

          <AnimatePresence mode="wait">
            {izinRevisiPending.length > 0 ? (
              <motion.div className="space-y-3">
                {izinRevisiPending.map((izin: any, index: number) => (
                  <motion.div
                    key={izin.id}
                    initial={{ opacity: 0, x: -20 }}
                    animate={{ opacity: 1, x: 0 }}
                    exit={{ opacity: 0, x: 20 }}
                    transition={{ duration: 0.3, delay: index * 0.1 }}
                    className="flex flex-col sm:flex-row justify-between items-start sm:items-center p-4 rounded-2xl bg-white border border-gray-100 shadow-xs hover:border-[#8B5E3C]/30 transition-all gap-4"
                  >
                    <div className="flex items-center gap-3.5">
                      <div className="w-11 h-11 bg-gradient-to-br from-[#8B5E3C] to-[#6F4E37] rounded-2xl flex items-center justify-center text-white font-bold text-base shadow-sm flex-shrink-0">
                        {izin.name?.charAt(0).toUpperCase()}
                      </div>
                      <div>
                        <p className="font-bold text-gray-800 text-sm sm:text-base">{izin.name}</p>
                        <div className="flex items-center gap-2 mt-1 flex-wrap">
                          <span className="px-2.5 py-0.5 bg-[#8B5E3C]/10 text-[#8B5E3C] text-[11px] font-bold rounded-full uppercase tracking-wider">
                            {izin.role}
                          </span>
                          <span className="flex items-center gap-1 text-xs text-gray-400 font-medium">
                            <Clock size={12} />
                            <span>Menunggu persetujuan hari ini</span>
                          </span>
                        </div>
                      </div>
                    </div>

                    <div className="flex gap-2.5 w-full sm:w-auto">
                      <button
                        onClick={() => {
                          setSelectedIzin(izin);
                          setShowFormRevisi(true);
                        }}
                        className="flex-1 sm:flex-none px-4 py-2.5 bg-emerald-600 text-white text-xs sm:text-sm font-bold rounded-xl hover:bg-emerald-700 transition flex items-center justify-center gap-1.5 shadow-xs active:scale-95"
                      >
                        <CheckCircle2 className="w-4 h-4" />
                        <span>Setujui</span>
                      </button>

                      <button
                        onClick={() => submitIzinRevisi(izin.id, 'reject')}
                        className="flex-1 sm:flex-none px-4 py-2.5 bg-rose-50 text-rose-600 text-xs sm:text-sm font-bold rounded-xl hover:bg-rose-100 transition flex items-center justify-center gap-1.5 active:scale-95"
                      >
                        <X className="w-4 h-4" />
                        <span>Tolak</span>
                      </button>
                    </div>
                  </motion.div>
                ))}
              </motion.div>
            ) : (
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                className="flex flex-col items-center justify-center py-8 text-center bg-white/60 rounded-2xl border border-dashed border-gray-200"
              >
                <div className="w-12 h-12 bg-emerald-50 rounded-2xl flex items-center justify-center mb-2.5 shadow-inner">
                  <CheckCircle2 className="w-6 h-6 text-emerald-600" />
                </div>
                <p className="text-gray-700 font-bold text-sm">Tidak ada permintaan izin revisi</p>
                <p className="text-xs text-gray-400 mt-0.5">Semua permintaan staf telah diproses dengan bersih</p>
              </motion.div>
            )}
          </AnimatePresence>
        </motion.div>

        {/* Status Input Harian Staff - RESPONSIVE */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          whileHover={{ scale: 1.01, y: -2 }}
          transition={{ duration: 0.3 }}
          className="bg-[#F2ECE4] p-5 sm:p-6 md:p-7 rounded-3xl shadow-xs border border-amber-200/60 hover:shadow-md hover:border-[#8B5E3C]/40 transition-all duration-300"
        >
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 mb-5">
            <div>
              <h3 className="text-base sm:text-lg font-bold text-gray-800 flex items-center gap-2.5">
                <div className="w-8 h-8 rounded-xl bg-[#8B5E3C]/10 flex items-center justify-center text-[#8B5E3C]">
                  <ClipboardCheck className="w-4 h-4 sm:w-5 sm:h-5" />
                </div>
                <span className="hidden sm:inline">Status Input Harian Staff</span>
                <span className="sm:hidden">Status Input Staff</span>
              </h3>
              <p className="text-xs sm:text-sm text-gray-500 mt-1">Monitoring kehadiran & input stok harian staff</p>
            </div>
            <div className="flex items-center gap-2">
              <span className="px-3.5 py-1.5 bg-emerald-50 text-emerald-700 text-xs sm:text-sm font-bold rounded-xl border border-emerald-100 shadow-2xs">
                ✨ {staffSudahInput?.length || 0} / {totalStaff || 0} Sudah Input
              </span>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 sm:gap-6">
            {/* Staff Sudah Input */}
            <div className="bg-white rounded-2xl border border-gray-100 shadow-xs overflow-hidden flex flex-col">
              <div className="px-4 py-3 bg-emerald-50/70 border-b border-emerald-100 flex items-center gap-2.5">
                <UserCheck className="w-4 h-4 text-emerald-600" />
                <span className="font-bold text-emerald-800 text-sm">Sudah Input</span>
                <span className="ml-auto px-2.5 py-0.5 bg-emerald-600 text-white text-xs font-bold rounded-full shadow-2xs">
                  {staffSudahInput?.length || 0}
                </span>
              </div>
              <div className="max-h-[260px] overflow-y-auto p-2">
                {staffSudahInput && staffSudahInput.length > 0 ? (
                  <div className="space-y-1.5">
                    {staffSudahInput.map((staff: any) => (
                      <div key={staff.id} className="px-3 py-2.5 rounded-xl flex items-center gap-3 bg-gray-50/50 hover:bg-emerald-50/30 transition-all">
                        <div className="w-9 h-9 bg-emerald-600 rounded-xl flex items-center justify-center text-white font-bold text-xs shadow-xs flex-shrink-0">
                          {staff.name?.charAt(0).toUpperCase()}
                        </div>
                        <div className="flex-1 min-w-0">
                          <p className="font-bold text-gray-800 text-sm truncate">{staff.name}</p>
                          <div className="flex items-center gap-2 mt-0.5">
                            <span className={`px-2 py-0.5 text-[10px] font-bold rounded-full uppercase tracking-wide ${
                              staff.role === 'bar'
                                ? 'bg-purple-100 text-purple-700'
                                : 'bg-orange-100 text-orange-700'
                            }`}>
                              {staff.role === 'bar' ? 'Bar' : 'Dapur'}
                            </span>
                            {staff.input_time && (
                              <span className="text-[11px] text-gray-400 font-medium flex items-center gap-1">
                                <Clock size={10} />
                                {new Date(staff.input_time).toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit' })}
                              </span>
                            )}
                          </div>
                        </div>
                        <CheckCircle2 className="w-5 h-5 text-emerald-500 flex-shrink-0" />
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="py-10 text-center">
                    <div className="w-10 h-10 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-2 text-gray-400">
                      <UserCheck className="w-5 h-5" />
                    </div>
                    <p className="text-xs text-gray-400 italic">Belum ada staff yang melakukan input</p>
                  </div>
                )}
              </div>
            </div>

            {/* Staff Belum Input */}
            <div className="bg-white rounded-2xl border border-gray-100 shadow-xs overflow-hidden flex flex-col">
              <div className="px-4 py-3 bg-rose-50/70 border-b border-rose-100 flex items-center gap-2.5">
                <UserX className="w-4 h-4 text-rose-600" />
                <span className="font-bold text-rose-800 text-sm">Belum Input</span>
                <span className="ml-auto px-2.5 py-0.5 bg-rose-600 text-white text-xs font-bold rounded-full shadow-2xs">
                  {staffBelumInput?.length || 0}
                </span>
              </div>
              <div className="max-h-[260px] overflow-y-auto p-2">
                {staffBelumInput && staffBelumInput.length > 0 ? (
                  <div className="space-y-1.5">
                    {staffBelumInput.map((staff: any) => (
                      <div key={staff.id} className="px-3 py-2.5 rounded-xl flex items-center gap-3 bg-gray-50/50 hover:bg-rose-50/30 transition-all">
                        <div className="w-9 h-9 bg-rose-500 rounded-xl flex items-center justify-center text-white font-bold text-xs shadow-xs flex-shrink-0">
                          {staff.name?.charAt(0).toUpperCase()}
                        </div>
                        <div className="flex-1 min-w-0">
                          <p className="font-bold text-gray-800 text-sm truncate">{staff.name}</p>
                          <span className={`px-2 py-0.5 text-[10px] font-bold rounded-full uppercase tracking-wider ${
                            staff.role === 'bar'
                              ? 'bg-purple-100 text-purple-700'
                              : 'bg-orange-100 text-orange-700'
                          }`}>
                            {staff.role === 'bar' ? 'Bar' : 'Dapur'}
                          </span>
                        </div>
                        <XCircle className="w-5 h-5 text-rose-500 flex-shrink-0" />
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="py-10 text-center">
                    <div className="w-10 h-10 bg-emerald-50 rounded-full flex items-center justify-center mx-auto mb-2">
                      <CheckCircle2 className="w-5 h-5 text-emerald-600" />
                    </div>
                    <p className="text-xs font-bold text-emerald-700">Luar biasa! Semua staff sudah input.</p>
                  </div>
                )}
              </div>
            </div>
          </div>
        </motion.div>

        {/* ============================================= */}
        {/* SECTION KHUSUS OWNER - RINGKASAN EKSEKUTIF - RESPONSIVE */}
        {/* ============================================= */}
        {isOwner && ownerData && (
          <>
            {/* Header Ringkasan Eksekutif */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
              className="bg-[#F9F6F3] p-4 sm:p-5 md:p-6 rounded-xl sm:rounded-2xl shadow-sm border border-gray-100"
            >
              <div className="flex items-center gap-3 mb-4">
                <div className="w-10 h-10 sm:w-12 sm:h-12 bg-[#8B5E3C] rounded-lg sm:rounded-xl flex items-center justify-center flex-shrink-0">
                  <Crown className="w-5 h-5 sm:w-6 sm:h-6 text-white" />
                </div>
                <div className="flex-1">
                  <h3 className="text-lg sm:text-xl font-bold text-gray-800">Ringkasan Eksekutif</h3>
                  <p className="text-gray-500 text-xs sm:text-sm">Pemantauan & Analisis khusus Owner</p>
                </div>
                <a
                  href={route('dashboard.owner.stock-report.pdf')}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center gap-2 px-3 py-2 rounded-lg bg-[#8B5E3C] text-white text-xs sm:text-sm font-semibold hover:bg-[#6F4E37] transition"
                >
                  <Download className="w-4 h-4" />
                  <span>Report 7 Hari (PDF)</span>
                </a>
              </div>

              {/* Executive Stats Cards - RESPONSIVE */}
              <div className="grid grid-cols-2 lg:grid-cols-4 gap-2 sm:gap-3 md:gap-4 mt-4">
                <div
                  onClick={() => setShowWeeklyActivityDetail(true)}
                  className="bg-white rounded-lg sm:rounded-xl p-3 sm:p-4 border border-gray-100 shadow-sm cursor-pointer hover:bg-gray-50 hover:border-[#8B5E3C]/30 transition group"
                >
                  <div className="flex items-center justify-between mb-1 sm:mb-2">
                    <div className="flex items-center gap-1 sm:gap-2">
                      <Activity className="w-3 h-3 sm:w-4 sm:h-4 text-[#8B5E3C]" />
                      <span className="text-gray-500 text-[10px] sm:text-xs font-medium truncate">Aktivitas Minggu Ini</span>
                    </div>
                    <Eye className="w-3 h-3 text-gray-400 group-hover:text-[#8B5E3C] transition" />
                  </div>
                  <p className="text-xl sm:text-2xl font-bold text-gray-800">{ownerData.activityThisWeek}</p>
                  <p className={`text-[10px] sm:text-xs ${ownerData.activityGrowth >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                    {ownerData.activityGrowth >= 0 ? '↑' : '↓'} {Math.abs(ownerData.activityGrowth)}%
                  </p>
                </div>

                <div
                  onClick={() => setShowWeeklyLoginDetail(true)}
                  className="bg-white rounded-lg sm:rounded-xl p-3 sm:p-4 border border-gray-100 shadow-sm cursor-pointer hover:bg-gray-50 hover:border-[#8B5E3C]/30 transition group"
                >
                  <div className="flex items-center justify-between mb-1 sm:mb-2">
                    <div className="flex items-center gap-1 sm:gap-2">
                      <LogIn className="w-3 h-3 sm:w-4 sm:h-4 text-[#8B5E3C]" />
                      <span className="text-gray-500 text-[10px] sm:text-xs font-medium truncate">Masuk Minggu Ini</span>
                    </div>
                    <Eye className="w-3 h-3 text-gray-400 group-hover:text-[#8B5E3C] transition" />
                  </div>
                  <p className="text-xl sm:text-2xl font-bold text-gray-800">{ownerData.loginThisWeek}</p>
                  <p className={`text-[10px] sm:text-xs ${ownerData.loginGrowth >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                    {ownerData.loginGrowth >= 0 ? '↑' : '↓'} {Math.abs(ownerData.loginGrowth)}%
                  </p>
                </div>

                <div
                  onClick={() => setShowSupervisorDetail(true)}
                  className="bg-white rounded-lg sm:rounded-xl p-3 sm:p-4 border border-gray-100 shadow-sm cursor-pointer hover:bg-gray-50 hover:border-[#8B5E3C]/30 transition group"
                >
                  <div className="flex items-center justify-between mb-1 sm:mb-2">
                    <div className="flex items-center gap-1 sm:gap-2">
                      <UserCog className="w-3 h-3 sm:w-4 sm:h-4 text-[#8B5E3C]" />
                      <span className="text-gray-500 text-[10px] sm:text-xs font-medium truncate">Total Supervisor</span>
                    </div>
                    <Eye className="w-3 h-3 text-gray-400 group-hover:text-[#8B5E3C] transition" />
                  </div>
                  <p className="text-xl sm:text-2xl font-bold text-gray-800">{ownerData.totalSupervisor}</p>
                  <p className="text-[10px] sm:text-xs text-gray-500">Pengawas</p>
                </div>

                <div
                  onClick={() => setShowIzinProcessedDetail(true)}
                  className="bg-white rounded-lg sm:rounded-xl p-3 sm:p-4 border border-gray-100 shadow-sm cursor-pointer hover:bg-gray-50 hover:border-[#8B5E3C]/30 transition group"
                >
                  <div className="flex items-center justify-between mb-1 sm:mb-2">
                    <div className="flex items-center gap-1 sm:gap-2">
                      <ShieldCheck className="w-3 h-3 sm:w-4 sm:h-4 text-[#8B5E3C]" />
                      <span className="text-gray-500 text-[10px] sm:text-xs font-medium truncate">Izin Diproses</span>
                    </div>
                    <Eye className="w-3 h-3 text-gray-400 group-hover:text-[#8B5E3C] transition" />
                  </div>
                  <p className="text-xl sm:text-2xl font-bold text-gray-800">{ownerData.izinProcessedThisMonth}</p>
                  <p className="text-[10px] sm:text-xs text-gray-500">Bulan ini</p>
                </div>
              </div>
            </motion.div>

            {/* Report Hari Ini (Stok Masuk & Terpakai) */}
            {todayStockReport && (
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5 }}
                className="bg-[#F9F6F3] p-4 sm:p-5 md:p-6 rounded-xl sm:rounded-2xl shadow-sm border border-gray-100"
              >
                <div className="flex items-center justify-between mb-3 sm:mb-4">
                  <div>
                    <h3 className="text-base sm:text-lg font-bold text-gray-800 flex items-center gap-2">
                      <Calendar className="w-4 h-4 sm:w-5 sm:h-5 text-[#8B5E3C]" />
                      Report Hari Ini
                    </h3>
                    <p className="text-xs sm:text-sm text-gray-500 mt-1">
                      {new Date(todayStockReport.date + 'T00:00:00').toLocaleDateString('id-ID', {
                        weekday: 'long',
                        day: 'numeric',
                        month: 'long',
                        year: 'numeric',
                      })}
                    </p>
                  </div>
                </div>

                <div className="grid grid-cols-1 lg:grid-cols-2 gap-3 sm:gap-4">
                  {/* Tabel Stok Masuk */}
                  <div className="bg-white rounded-lg sm:rounded-xl border border-gray-200 overflow-hidden">
                    <div className="px-3 sm:px-4 py-2 sm:py-3 bg-[#8B5E3C] border-b border-[#6F4E37]">
                      <p className="text-sm font-semibold text-white">Stok Masuk</p>
                      <p className="text-xs text-white/80">Bahan apa yang masuk hari ini</p>
                    </div>

                    {todayStockReport.rows &&
                    todayStockReport.rows.some((r: any) => (r?.jenis ?? '') === 'Mentah' && (r?.masuk ?? 0) > 0) ? (
                      <div className="overflow-x-auto">
                        <table className="min-w-full text-sm">
                          <thead className="bg-[#F9F6F3]">
                            <tr>
                              <th className="text-left px-3 sm:px-4 py-2 text-xs font-semibold text-gray-600">Divisi</th>
                              <th className="text-left px-3 sm:px-4 py-2 text-xs font-semibold text-gray-600">Nama</th>
                              <th className="text-right px-3 sm:px-4 py-2 text-xs font-semibold text-gray-600">Masuk</th>
                            </tr>
                          </thead>
                          <tbody className="divide-y divide-gray-100">
                            {todayStockReport.rows
                              .filter((r: any) => (r?.jenis ?? '') === 'Mentah' && (r?.masuk ?? 0) > 0)
                              .map((r: any, idx: number) => (
                                <tr
                                  key={`masuk-${r.divisi}-${r.jenis}-${r.nama}-${idx}`}
                                  className={`${idx % 2 === 0 ? 'bg-white' : 'bg-gray-50/60'} hover:bg-[#8B5E3C]/5 transition-colors`}
                                >
                                  <td className="px-3 sm:px-4 py-2 text-gray-700 whitespace-nowrap">{r.divisi}</td>
                                  <td className="px-3 sm:px-4 py-2 text-gray-800">
                                    <div className="font-medium">{r.nama}</div>
                                    <div className="mt-0.5 flex flex-wrap gap-1.5 text-[11px] leading-4">
                                      {r.jenis ? (
                                        <span className="inline-flex items-center rounded-full border border-[#8B5E3C]/20 bg-[#8B5E3C]/10 px-2 py-0.5 font-medium text-[#8B5E3C]">
                                          {r.jenis}
                                        </span>
                                      ) : null}
                                      {r.staff && r.staff !== '-' ? (
                                        <span className="inline-flex items-center rounded-full border border-gray-200 bg-white px-2 py-0.5 font-medium text-gray-600">
                                          Input: {r.staff}
                                        </span>
                                      ) : null}
                                    </div>
                                  </td>
                                  <td className="px-3 sm:px-4 py-2 text-right font-semibold text-gray-800 whitespace-nowrap">
                                    {r.masuk} <span className="text-xs text-gray-400 font-normal">{r.unit}</span>
                                  </td>
                                </tr>
                              ))}
                          </tbody>
                        </table>
                      </div>
                    ) : (
                      <div className="py-6 text-center">
                        <p className="text-sm text-gray-600 font-medium">Belum ada stok masuk hari ini</p>
                      </div>
                    )}
                  </div>

                  {/* Tabel Stok Pemakaian */}
                  <div className="bg-white rounded-lg sm:rounded-xl border border-gray-200 overflow-hidden">
                    <div className="px-3 sm:px-4 py-2 sm:py-3 bg-[#8B5E3C] border-b border-[#6F4E37]">
                      <p className="text-sm font-semibold text-white">Stok Pemakaian</p>
                      <p className="text-xs text-white/80">Bahan apa yang terpakai hari ini</p>
                    </div>

                    {todayStockReport.rows &&
                    todayStockReport.rows.some((r: any) => (r?.jenis ?? '') === 'Menu' && (r?.terpakai ?? 0) > 0) ? (
                      <div className="overflow-x-auto">
                        <table className="min-w-full text-sm">
                          <thead className="bg-[#F9F6F3]">
                            <tr>
                              <th className="text-left px-3 sm:px-4 py-2 text-xs font-semibold text-gray-600">Divisi</th>
                              <th className="text-left px-3 sm:px-4 py-2 text-xs font-semibold text-gray-600">Nama</th>
                              <th className="text-right px-3 sm:px-4 py-2 text-xs font-semibold text-gray-600">Terpakai</th>
                            </tr>
                          </thead>
                          <tbody className="divide-y divide-gray-100">
                            {todayStockReport.rows
                              .filter((r: any) => (r?.jenis ?? '') === 'Menu' && (r?.terpakai ?? 0) > 0)
                              .map((r: any, idx: number) => (
                                <tr
                                  key={`pakai-${r.divisi}-${r.jenis}-${r.nama}-${idx}`}
                                  className={`${idx % 2 === 0 ? 'bg-white' : 'bg-gray-50/60'} hover:bg-[#8B5E3C]/5 transition-colors`}
                                >
                                  <td className="px-3 sm:px-4 py-2 text-gray-700 whitespace-nowrap">{r.divisi}</td>
                                  <td className="px-3 sm:px-4 py-2 text-gray-800">
                                    <div className="font-medium">{r.nama}</div>
                                    <div className="mt-0.5 flex flex-wrap gap-1.5 text-[11px] leading-4">
                                      {r.jenis ? (
                                        <span className="inline-flex items-center rounded-full border border-[#8B5E3C]/20 bg-[#8B5E3C]/10 px-2 py-0.5 font-medium text-[#8B5E3C]">
                                          {r.jenis}
                                        </span>
                                      ) : null}
                                      {r.staff && r.staff !== '-' ? (
                                        <span className="inline-flex items-center rounded-full border border-gray-200 bg-white px-2 py-0.5 font-medium text-gray-600">
                                          Input: {r.staff}
                                        </span>
                                      ) : null}
                                    </div>
                                  </td>
                                  <td className="px-3 sm:px-4 py-2 text-right font-semibold text-gray-800 whitespace-nowrap">
                                    {r.terpakai} <span className="text-xs text-gray-400 font-normal">{r.unit}</span>
                                  </td>
                                </tr>
                              ))}
                          </tbody>
                        </table>
                      </div>
                    ) : (
                      <div className="py-6 text-center">
                        <p className="text-sm text-gray-600 font-medium">Belum ada pemakaian stok hari ini</p>
                      </div>
                    )}
                  </div>
                </div>
              </motion.div>
            )}

            {/* Grafik Aktivitas & Distribusi Pengguna - RESPONSIVE */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 sm:gap-6">
              {/* Grafik Aktivitas Mingguan */}
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5 }}
                className="bg-[#F9F6F3] p-4 sm:p-5 md:p-6 rounded-xl sm:rounded-2xl shadow-sm border border-gray-100"
              >
                <div className="flex items-center justify-between mb-3 sm:mb-4">
                  <div className="flex items-center gap-2">
                    <BarChart3 className="w-4 h-4 sm:w-5 sm:h-5 text-[#8B5E3C]" />
                    <h3 className="text-sm sm:text-base md:text-lg font-bold text-gray-800">Aktivitas 7 Hari</h3>
                  </div>
                  <button
                    onClick={() => setShowActivityDetail(true)}
                    className="text-xs sm:text-sm text-[#8B5E3C] hover:underline font-medium flex items-center gap-1"
                  >
                    <Eye className="w-3 h-3 sm:w-4 sm:h-4" />
                    <span className="hidden sm:inline">Lihat Detail</span>
                    <span className="sm:hidden">Detail</span>
                  </button>
                </div>
                <div className="min-w-0 min-h-[160px] h-[160px] sm:h-[180px] md:h-[200px]">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart
                      data={ownerData.activityPerDay}
                      onClick={(data: any) => {
                        if (data && data.activePayload && data.activePayload[0]) {
                          setSelectedDayActivity(data.activePayload[0].payload);
                          setShowActivityDetail(true);
                        }
                      }}
                      style={{ cursor: 'pointer' }}
                    >
                      <CartesianGrid strokeDasharray="3 3" stroke="#E5E7EB" />
                      <XAxis
                        dataKey="date"
                        fontSize={10}
                        tickFormatter={(value) => new Date(value).toLocaleDateString('id-ID', { weekday: 'short' })}
                      />
                      <YAxis fontSize={10} />
                      <Tooltip
                        contentStyle={{ backgroundColor: '#fff', border: 'none', borderRadius: '8px', boxShadow: '0 4px 12px rgba(0,0,0,0.1)' }}
                        labelFormatter={(value) => new Date(value).toLocaleDateString('id-ID', { weekday: 'long', day: 'numeric', month: 'short' })}
                        formatter={(value: any) => [`${value} aktivitas`, 'Total']}
                      />
                      <Bar dataKey="total" fill="#8B5E3C" radius={[4, 4, 0, 0]} />
                    </BarChart>
                  </ResponsiveContainer>
                </div>
                <p className="text-[10px] sm:text-xs text-gray-400 text-center mt-2">Klik bar untuk melihat detail</p>
              </motion.div>

              {/* Distribusi Pengguna per Peran - RESPONSIVE */}
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5 }}
                className="bg-[#F9F6F3] p-4 sm:p-5 md:p-6 rounded-xl sm:rounded-2xl shadow-sm border border-gray-100"
              >
                <div className="flex items-center gap-2 mb-3 sm:mb-4">
                  <Users className="w-4 h-4 sm:w-5 sm:h-5 text-[#8B5E3C]" />
                  <h3 className="text-sm sm:text-base md:text-lg font-bold text-gray-800">Distribusi Pengguna</h3>
                </div>
                <div className="space-y-2 sm:space-y-3">
                  <div className="flex items-center justify-between p-2 sm:p-3 bg-white rounded-lg sm:rounded-xl border border-[#8B5E3C]/20">
                    <div className="flex items-center gap-2 sm:gap-3">
                      <Crown className="w-4 h-4 sm:w-[18px] sm:h-[18px] text-[#8B5E3C]" />
                      <span className="font-medium text-gray-700 text-sm sm:text-base">Owner</span>
                    </div>
                    <span className="text-base sm:text-lg font-bold text-[#8B5E3C]">{ownerData.usersByRole?.owner || 1}</span>
                  </div>
                  <div className="flex items-center justify-between p-2 sm:p-3 bg-white rounded-lg sm:rounded-xl border border-blue-100">
                    <div className="flex items-center gap-2 sm:gap-3">
                      <UserCog className="w-4 h-4 sm:w-[18px] sm:h-[18px] text-blue-600" />
                      <span className="font-medium text-gray-700 text-sm sm:text-base">Supervisor</span>
                    </div>
                    <span className="text-base sm:text-lg font-bold text-blue-600">{ownerData.totalSupervisor}</span>
                  </div>
                  <div className="flex items-center justify-between p-2 sm:p-3 bg-white rounded-lg sm:rounded-xl border border-purple-100">
                    <div className="flex items-center gap-2 sm:gap-3">
                      <span className="text-base sm:text-lg">🍸</span>
                      <span className="font-medium text-gray-700 text-sm sm:text-base">Staf Bar</span>
                    </div>
                    <span className="text-base sm:text-lg font-bold text-purple-600">{ownerData.totalBarStaff}</span>
                  </div>
                  <div className="flex items-center justify-between p-2 sm:p-3 bg-white rounded-lg sm:rounded-xl border border-orange-100">
                    <div className="flex items-center gap-2 sm:gap-3">
                      <span className="text-base sm:text-lg">🍳</span>
                      <span className="font-medium text-gray-700 text-sm sm:text-base">Staf Dapur</span>
                    </div>
                    <span className="text-base sm:text-lg font-bold text-orange-600">{ownerData.totalDapurStaff}</span>
                  </div>
                </div>
              </motion.div>
            </div>
          </>
        )}
      </div>

      {/* MODAL 1: PILIH STOK - RESPONSIVE */}
      <AnimatePresence>
        {showPilihStok && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center z-50 p-4"
          >
            <motion.div
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              className="bg-white rounded-xl sm:rounded-2xl p-4 sm:p-6 w-full max-w-[300px] sm:max-w-[340px] shadow-xl"
            >
              <h3 className="text-base sm:text-lg font-bold text-gray-800 text-center mb-2">
                Lihat Detail Stok
              </h3>
              <p className="text-xs sm:text-sm text-gray-500 text-center mb-4 sm:mb-6">
                Pilih divisi untuk melihat detail
              </p>

              <div className="grid grid-cols-2 gap-2 sm:gap-3">
                <button
                  onClick={() => router.visit("/stok-harian/bar")}
                  className="py-3 sm:py-4 rounded-lg sm:rounded-xl bg-[#8B5E3C] text-white font-semibold hover:bg-[#6F4E37] transition flex flex-col items-center gap-1 sm:gap-2 active:scale-95"
                >
                  <span className="text-xl sm:text-2xl">🍸</span>
                  <span className="text-sm sm:text-base">Bar</span>
                </button>

                <button
                  onClick={() => router.visit("/stok-harian/dapur")}
                  className="py-3 sm:py-4 rounded-lg sm:rounded-xl bg-[#8B5E3C] text-white font-semibold hover:bg-[#6F4E37] transition flex flex-col items-center gap-1 sm:gap-2 active:scale-95"
                >
                  <span className="text-xl sm:text-2xl">🍳</span>
                  <span className="text-sm sm:text-base">Dapur</span>
                </button>
              </div>

              <button
                onClick={() => setShowPilihStok(false)}
                className="mt-3 sm:mt-4 w-full py-2 sm:py-2.5 text-xs sm:text-sm text-gray-500 hover:text-gray-800 hover:bg-gray-100 rounded-lg transition font-medium"
              >
                Batal
              </button>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* MODAL 2: FORM IZIN REVISI - RESPONSIVE */}
      <AnimatePresence>
        {showFormRevisi && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center z-50 p-3 sm:p-4"
          >
            <motion.div
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              className="bg-white rounded-xl sm:rounded-2xl p-4 sm:p-6 w-full max-w-[360px] sm:max-w-[420px] shadow-xl max-h-[90vh] overflow-y-auto"
            >
              {/* Header */}
              <div className="flex items-center justify-between mb-5">
                <h3 className="text-lg font-bold text-gray-800">Izin Revisi Stok</h3>
                <button
                  onClick={() => setShowFormRevisi(false)}
                  className="w-8 h-8 rounded-full bg-gray-100 hover:bg-gray-200 flex items-center justify-center transition"
                >
                  <X size={18} className="text-gray-500" />
                </button>
              </div>

              {/* User info */}
              <div className="flex items-center gap-3 p-3 bg-[#F9F6F3] rounded-xl mb-5">
                <div className="w-10 h-10 bg-[#8B5E3C] rounded-full flex items-center justify-center text-white font-bold">
                  {selectedIzin?.name?.charAt(0).toUpperCase()}
                </div>
                <div>
                  <p className="font-semibold text-gray-800">{selectedIzin?.name}</p>
                  <span className="text-xs text-gray-500">{selectedIzin?.role}</span>
                </div>
              </div>

              {/* Form */}
              <div className="space-y-4">
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="text-sm font-medium text-gray-700 mb-1.5 block">Tanggal Mulai</label>
                    <input
                      type="date"
                      className="w-full border border-gray-200 rounded-lg px-3 py-2.5 focus:ring-2 focus:ring-[#8B5E3C]/20 focus:border-[#8B5E3C] transition outline-none text-sm"
                      onChange={(e) =>
                        setFormRevisi({ ...formRevisi, tanggalMulai: e.target.value })
                      }
                    />
                  </div>

                  <div>
                    <label className="text-sm font-medium text-gray-700 mb-1.5 block">Jam Mulai</label>
                    <input
                      type="time"
                      className="w-full border border-gray-200 rounded-lg px-3 py-2.5 focus:ring-2 focus:ring-[#8B5E3C]/20 focus:border-[#8B5E3C] transition outline-none text-sm"
                      onChange={(e) =>
                        setFormRevisi({ ...formRevisi, jamMulai: e.target.value })
                      }
                    />
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="text-sm font-medium text-gray-700 mb-1.5 block">Tanggal Selesai</label>
                    <input
                      type="date"
                      className="w-full border border-gray-200 rounded-lg px-3 py-2.5 focus:ring-2 focus:ring-[#8B5E3C]/20 focus:border-[#8B5E3C] transition outline-none text-sm"
                      onChange={(e) =>
                        setFormRevisi({ ...formRevisi, tanggalSelesai: e.target.value })
                      }
                    />
                  </div>

                  <div>
                    <label className="text-sm font-medium text-gray-700 mb-1.5 block">Jam Selesai</label>
                    <input
                      type="time"
                      className="w-full border border-gray-200 rounded-lg px-3 py-2.5 focus:ring-2 focus:ring-[#8B5E3C]/20 focus:border-[#8B5E3C] transition outline-none text-sm"
                      onChange={(e) =>
                        setFormRevisi({ ...formRevisi, jamSelesai: e.target.value })
                      }
                    />
                  </div>
                </div>
              </div>

              {/* Actions */}
              <div className="flex gap-3 mt-6">
                <button
                  onClick={() => {
                    if (
                      !formRevisi.tanggalMulai ||
                      !formRevisi.jamMulai ||
                      !formRevisi.tanggalSelesai ||
                      !formRevisi.jamSelesai
                    ) {
                      alert("Lengkapi semua waktu izin revisi");
                      return;
                    }
                    // Submit ke backend
                    submitIzinRevisi(selectedIzin.id, 'approve', formRevisi);
                  }}
                  className="flex-1 bg-green-600 text-white py-2.5 rounded-lg hover:bg-green-700 font-semibold transition flex items-center justify-center gap-2"
                >
                  <CheckCircle2 size={18} />
                  Setujui
                </button>

                <button
                  onClick={() => setShowFormRevisi(false)}
                  className="flex-1 bg-gray-100 py-2.5 rounded-lg hover:bg-gray-200 font-semibold transition"
                >
                  Batal
                </button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* MODAL DETAIL AKTIVITAS 7 HARI */}
      <AnimatePresence>
        {showActivityDetail && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center z-50 p-4"
          >
            <motion.div
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              className="bg-white rounded-2xl p-6 w-full max-w-2xl shadow-xl max-h-[80vh] overflow-hidden flex flex-col"
            >
              <div className="flex items-center justify-between mb-4">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 bg-[#8B5E3C] rounded-xl flex items-center justify-center">
                    <Activity size={20} className="text-white" />
                  </div>
                  <div>
                    <h3 className="text-lg font-bold text-gray-800">
                      {selectedDayActivity
                        ? `Aktivitas ${new Date(selectedDayActivity.date).toLocaleDateString('id-ID', { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' })}`
                        : 'Detail Aktivitas 7 Hari Terakhir'}
                    </h3>
                    <p className="text-sm text-gray-500">
                      {selectedDayActivity
                        ? `Total ${selectedDayActivity.total} aktivitas`
                        : 'Ringkasan aktivitas per hari'}
                    </p>
                  </div>
                </div>
                <button
                  onClick={() => {
                    setShowActivityDetail(false);
                    setSelectedDayActivity(null);
                  }}
                  className="w-8 h-8 rounded-full bg-gray-100 hover:bg-gray-200 flex items-center justify-center transition"
                >
                  <X size={18} className="text-gray-500" />
                </button>
              </div>

              <div className="overflow-y-auto flex-1">
                {selectedDayActivity ? (
                  // Detail aktivitas untuk hari tertentu
                  <div className="space-y-3">
                    {selectedDayActivity.activities?.length > 0 ? (
                      selectedDayActivity.activities.map((activity: any, index: number) => (
                        <div key={index} className="p-3 bg-[#F9F6F3] rounded-xl border border-gray-100">
                          <div className="flex items-start gap-3">
                            <div className={`w-8 h-8 rounded-full flex items-center justify-center text-white text-xs font-bold ${
                              activity.activity === 'Login' ? 'bg-green-500' :
                              activity.activity === 'Logout' ? 'bg-red-500' :
                              activity.activity?.includes('Tambah') ? 'bg-blue-500' :
                              activity.activity?.includes('Update') ? 'bg-amber-500' :
                              activity.activity?.includes('Hapus') ? 'bg-red-500' :
                              'bg-gray-500'
                            }`}>
                              {activity.user_name?.charAt(0).toUpperCase() || '?'}
                            </div>
                            <div className="flex-1 min-w-0">
                              <div className="flex items-center gap-2 flex-wrap">
                                <span className="font-semibold text-gray-800 text-sm">{activity.user_name}</span>
                                <span className={`px-1.5 py-0.5 text-xs font-medium rounded ${
                                  activity.user_role === 'owner' ? 'bg-[#8B5E3C]/20 text-[#8B5E3C]' :
                                  activity.user_role === 'supervisor' ? 'bg-blue-100 text-blue-700' :
                                  activity.user_role === 'bar' ? 'bg-purple-100 text-purple-700' :
                                  'bg-orange-100 text-orange-700'
                                }`}>
                                  {activity.user_role}
                                </span>
                              </div>
                              <p className="text-sm text-gray-600 mt-0.5">{activity.activity}</p>
                              {activity.description && (
                                <p className="text-xs text-gray-400 mt-1">{activity.description}</p>
                              )}
                              <p className="text-xs text-gray-400 mt-1">
                                {new Date(activity.created_at).toLocaleString('id-ID', {
                                  hour: '2-digit', minute: '2-digit'
                                })}
                              </p>
                            </div>
                          </div>
                        </div>
                      ))
                    ) : (
                      <div className="text-center py-8 text-gray-500">
                        <Activity size={32} className="mx-auto mb-2 text-gray-300" />
                        <p>Belum ada detail aktivitas</p>
                      </div>
                    )}
                  </div>
                ) : (
                  // Ringkasan semua hari
                  <div className="space-y-3">
                    {ownerData?.activityPerDay?.map((day: any, index: number) => (
                      <div
                        key={index}
                        className="p-4 bg-[#F9F6F3] rounded-xl border border-gray-100 hover:bg-[#F0EBE5] transition cursor-pointer"
                        onClick={() => setSelectedDayActivity(day)}
                      >
                        <div className="flex items-center justify-between">
                          <div className="flex items-center gap-3">
                            <div className="w-10 h-10 bg-[#8B5E3C] rounded-xl flex items-center justify-center text-white font-bold">
                              {new Date(day.date).getDate()}
                            </div>
                            <div>
                              <p className="font-semibold text-gray-800">
                                {new Date(day.date).toLocaleDateString('id-ID', { weekday: 'long', day: 'numeric', month: 'long' })}
                              </p>
                              <p className="text-sm text-gray-500">Klik untuk lihat detail</p>
                            </div>
                          </div>
                          <div className="flex items-center gap-2">
                            <span className="text-2xl font-bold text-[#8B5E3C]">{day.total}</span>
                            <span className="text-sm text-gray-500">aktivitas</span>
                            <Eye size={16} className="text-gray-400 ml-2" />
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>

              <div className="flex gap-3 mt-4 pt-4 border-t border-gray-100">
                {selectedDayActivity && (
                  <button
                    onClick={() => setSelectedDayActivity(null)}
                    className="flex-1 bg-gray-100 py-2.5 rounded-lg hover:bg-gray-200 font-semibold transition"
                  >
                    Kembali ke Ringkasan
                  </button>
                )}
                <button
                  onClick={() => {
                    setShowActivityDetail(false);
                    setSelectedDayActivity(null);
                  }}
                  className={`${selectedDayActivity ? 'flex-1' : 'w-full'} bg-[#8B5E3C] text-white py-2.5 rounded-lg hover:bg-[#7A5235] font-semibold transition`}
                >
                  Tutup
                </button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* MODAL DETAIL RINGKASAN EKSEKUTIF */}
      <AnimatePresence>
        {showExecSummaryDetail && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center z-50 p-4"
          >
            <motion.div
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              className="bg-white rounded-2xl p-6 w-full max-w-3xl shadow-xl max-h-[85vh] overflow-hidden flex flex-col"
            >
              {/* Header */}
              <div className="flex items-center justify-between mb-4">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 bg-[#8B5E3C] rounded-xl flex items-center justify-center">
                    <Crown size={20} className="text-white" />
                  </div>
                  <div>
                    <h3 className="text-lg font-bold text-gray-800">Detail Ringkasan Eksekutif</h3>
                    <p className="text-sm text-gray-500">Aktivitas & Riwayat Login Terbaru</p>
                  </div>
                </div>
                <button
                  onClick={() => setShowExecSummaryDetail(false)}
                  className="w-8 h-8 rounded-full bg-gray-100 hover:bg-gray-200 flex items-center justify-center transition"
                >
                  <X size={18} className="text-gray-500" />
                </button>
              </div>

              {/* Tab Navigation */}
              <div className="flex gap-2 mb-4 border-b border-gray-200">
                <button
                  onClick={() => setExecDetailTab('activity')}
                  className={`px-4 py-2 text-sm font-medium transition border-b-2 -mb-px ${
                    execDetailTab === 'activity'
                      ? 'border-[#8B5E3C] text-[#8B5E3C]'
                      : 'border-transparent text-gray-500 hover:text-gray-700'
                  }`}
                >
                  <Activity className="w-4 h-4 inline mr-2" />
                  Aktivitas Terbaru
                </button>
                <button
                  onClick={() => setExecDetailTab('login')}
                  className={`px-4 py-2 text-sm font-medium transition border-b-2 -mb-px ${
                    execDetailTab === 'login'
                      ? 'border-[#8B5E3C] text-[#8B5E3C]'
                      : 'border-transparent text-gray-500 hover:text-gray-700'
                  }`}
                >
                  <LogIn className="w-4 h-4 inline mr-2" />
                  Riwayat Login
                </button>
              </div>
              {/* Tab Content */}
              <div className="overflow-y-auto flex-1">
                {execDetailTab === 'activity' ? (
                  // Aktivitas Terbaru
                  <div className="space-y-3">
                    {ownerData?.recentActivities?.length > 0 ? (
                      ownerData.recentActivities.map((activity: any, index: number) => (
                        <div key={index} className="p-3 bg-[#F9F6F3] rounded-xl border border-gray-100">
                          <div className="flex items-start gap-3">
                            <div className={`w-8 h-8 rounded-full flex items-center justify-center text-white text-xs font-bold ${
                              activity.activity === 'Login' ? 'bg-green-500' :
                              activity.activity === 'Logout' ? 'bg-red-500' :
                              activity.activity?.includes('Tambah') ? 'bg-blue-500' :
                              activity.activity?.includes('Update') ? 'bg-amber-500' :
                              activity.activity?.includes('Hapus') ? 'bg-red-500' :
                              'bg-gray-500'
                            }`}>
                              {activity.user_name?.charAt(0).toUpperCase() || '?'}
                            </div>
                            <div className="flex-1 min-w-0">
                              <div className="flex items-center gap-2 flex-wrap">
                                <span className="font-semibold text-gray-800 text-sm">{activity.user_name}</span>
                                <span className={`px-1.5 py-0.5 text-xs font-medium rounded ${
                                  activity.user_role === 'owner' ? 'bg-[#8B5E3C]/20 text-[#8B5E3C]' :
                                  activity.user_role === 'supervisor' ? 'bg-blue-100 text-blue-700' :
                                  activity.user_role === 'bar' ? 'bg-purple-100 text-purple-700' :
                                  'bg-orange-100 text-orange-700'
                                }`}>
                                  {activity.user_role}
                                </span>
                              </div>
                              <p className="text-sm text-gray-600 mt-0.5">{activity.activity}</p>
                              {activity.description && (
                                <p className="text-xs text-gray-400 mt-1">{activity.description}</p>
                              )}
                              <p className="text-xs text-gray-400 mt-1">
                                {new Date(activity.created_at).toLocaleString('id-ID', {
                                  day: 'numeric', month: 'short', year: 'numeric',
                                  hour: '2-digit', minute: '2-digit'
                                })}
                              </p>
                            </div>
                          </div>
                        </div>
                      ))
                    ) : (
                      <div className="text-center py-8 text-gray-500">
                        <Activity size={32} className="mx-auto mb-2 text-gray-300" />
                        <p>Belum ada aktivitas terbaru</p>
                      </div>
                    )}
                  </div>
                ) : (
                  // Riwayat Login
                  <div className="space-y-3">
                    {ownerData?.recentLogins?.length > 0 ? (
                      ownerData.recentLogins.map((login: any, index: number) => (
                        <div key={index} className="p-3 bg-[#F9F6F3] rounded-xl border border-gray-100">
                          <div className="flex items-start gap-3">
                            <div className={`w-8 h-8 rounded-full flex items-center justify-center text-white text-xs font-bold ${
                              login.is_online ? 'bg-green-500' : 'bg-gray-400'
                            }`}>
                              {login.user_name?.charAt(0).toUpperCase() || '?'}
                            </div>
                            <div className="flex-1 min-w-0">
                              <div className="flex items-center gap-2 flex-wrap">
                                <span className="font-semibold text-gray-800 text-sm">{login.user_name}</span>
                                <span className={`px-1.5 py-0.5 text-xs font-medium rounded ${
                                  login.user_role === 'owner' ? 'bg-[#8B5E3C]/20 text-[#8B5E3C]' :
                                  login.user_role === 'supervisor' ? 'bg-blue-100 text-blue-700' :
                                  login.user_role === 'bar' ? 'bg-purple-100 text-purple-700' :
                                  'bg-orange-100 text-orange-700'
                                }`}>
                                  {login.user_role}
                                </span>
                                {login.is_online && (
                                  <span className="px-1.5 py-0.5 text-xs font-medium rounded bg-green-100 text-green-700">
                                    Online
                                  </span>
                                )}
                              </div>
                              <div className="flex items-center gap-3 mt-1 text-xs text-gray-500">
                                <span className="flex items-center gap-1">
                                  {login.device_type === 'mobile' ? (
                                    <Smartphone className="w-3 h-3" />
                                  ) : (
                                    <Monitor className="w-3 h-3" />
                                  )}
                                  {login.device_type}
                                </span>
                                <span className="flex items-center gap-1">
                                  <Globe className="w-3 h-3" />
                                  {login.browser}
                                </span>
                                <span>{login.platform}</span>
                              </div>
                              <div className="flex items-center gap-4 mt-1 text-xs">
                                <span className="text-green-600 flex items-center gap-1">
                                  <LogIn className="w-3 h-3" />
                                  {new Date(login.login_at).toLocaleString('id-ID', {
                                    day: 'numeric', month: 'short',
                                    hour: '2-digit', minute: '2-digit'
                                  })}
                                </span>
                                {login.logout_at && (
                                  <span className="text-red-600 flex items-center gap-1">
                                    <LogOut className="w-3 h-3" />
                                    {new Date(login.logout_at).toLocaleString('id-ID', {
                                      day: 'numeric', month: 'short',
                                      hour: '2-digit', minute: '2-digit'
                                    })}
                                  </span>
                                )}
                              </div>
                              <p className="text-xs text-gray-400 mt-1">IP: {login.ip_address}</p>
                            </div>
                          </div>
                        </div>
                      ))
                    ) : (
                      <div className="text-center py-8 text-gray-500">
                        <LogIn size={32} className="mx-auto mb-2 text-gray-300" />
                        <p>Belum ada riwayat login</p>
                      </div>
                    )}
                  </div>
                )}
              </div>

              {/* Footer */}
              <div className="flex gap-3 mt-4 pt-4 border-t border-gray-100">
                <button
                  onClick={() => setShowExecSummaryDetail(false)}
                  className="w-full bg-[#8B5E3C] text-white py-2.5 rounded-lg hover:bg-[#7A5235] font-semibold transition"
                >
                  Tutup
                </button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* MODAL DETAIL AKTIVITAS MINGGU INI */}
      <AnimatePresence>
        {showWeeklyActivityDetail && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center z-50 p-4"
          >
            <motion.div
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              className="bg-white rounded-2xl p-6 w-full max-w-2xl shadow-xl max-h-[80vh] overflow-hidden flex flex-col"
            >
              <div className="flex items-center justify-between mb-4">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 bg-[#8B5E3C] rounded-xl flex items-center justify-center">
                    <Activity size={20} className="text-white" />
                  </div>
                  <div>
                    <h3 className="text-lg font-bold text-gray-800">Aktivitas Minggu Ini</h3>
                    <p className="text-sm text-gray-500">Total {ownerData?.activityThisWeek || 0} aktivitas dalam 7 hari terakhir</p>
                  </div>
                </div>
                <button
                  onClick={() => setShowWeeklyActivityDetail(false)}
                  className="w-8 h-8 rounded-full bg-gray-100 hover:bg-gray-200 flex items-center justify-center transition"
                >
                  <X size={18} className="text-gray-500" />
                </button>
              </div>

              <div className="overflow-y-auto flex-1">
                <div className="space-y-3">
                  {ownerData?.recentActivities?.length > 0 ? (
                    ownerData.recentActivities.map((activity: any, index: number) => (
                      <div key={index} className="p-3 bg-[#F9F6F3] rounded-xl border border-gray-100">
                        <div className="flex items-start gap-3">
                          <div className={`w-8 h-8 rounded-full flex items-center justify-center text-white text-xs font-bold ${
                            activity.activity === 'Login' ? 'bg-green-500' :
                            activity.activity === 'Logout' ? 'bg-red-500' :
                            activity.activity?.includes('Tambah') ? 'bg-blue-500' :
                            activity.activity?.includes('Update') ? 'bg-amber-500' :
                            activity.activity?.includes('Hapus') ? 'bg-red-500' :
                            'bg-gray-500'
                          }`}>
                            {activity.user_name?.charAt(0).toUpperCase() || '?'}
                          </div>
                          <div className="flex-1 min-w-0">
                            <div className="flex items-center gap-2 flex-wrap">
                              <span className="font-semibold text-gray-800 text-sm">{activity.user_name}</span>
                              <span className={`px-1.5 py-0.5 text-xs font-medium rounded ${
                                activity.user_role === 'owner' ? 'bg-[#8B5E3C]/20 text-[#8B5E3C]' :
                                activity.user_role === 'supervisor' ? 'bg-blue-100 text-blue-700' :
                                activity.user_role === 'bar' ? 'bg-purple-100 text-purple-700' :
                                'bg-orange-100 text-orange-700'
                              }`}>
                                {activity.user_role}
                              </span>
                            </div>
                            <p className="text-sm text-gray-600 mt-0.5">{activity.activity}</p>
                            {activity.description && (
                              <p className="text-xs text-gray-400 mt-1">{activity.description}</p>
                            )}
                            <p className="text-xs text-gray-400 mt-1">
                              {new Date(activity.created_at).toLocaleString('id-ID', {
                                day: 'numeric', month: 'short', year: 'numeric',
                                hour: '2-digit', minute: '2-digit'
                              })}
                            </p>
                          </div>
                        </div>
                      </div>
                    ))
                  ) : (
                    <div className="text-center py-8 text-gray-500">
                      <Activity size={32} className="mx-auto mb-2 text-gray-300" />
                      <p>Belum ada aktivitas minggu ini</p>
                    </div>
                  )}
                </div>
              </div>

              <div className="flex gap-3 mt-4 pt-4 border-t border-gray-100">
                <button
                  onClick={() => setShowWeeklyActivityDetail(false)}
                  className="w-full bg-[#8B5E3C] text-white py-2.5 rounded-lg hover:bg-[#7A5235] font-semibold transition"
                >
                  Tutup
                </button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* MODAL DETAIL LOGIN MINGGU INI */}
      <AnimatePresence>
        {showWeeklyLoginDetail && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center z-50 p-4"
          >
            <motion.div
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              className="bg-white rounded-2xl p-6 w-full max-w-2xl shadow-xl max-h-[80vh] overflow-hidden flex flex-col"
            >
              <div className="flex items-center justify-between mb-4">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 bg-[#8B5E3C] rounded-xl flex items-center justify-center">
                    <LogIn size={20} className="text-white" />
                  </div>
                  <div>
                    <h3 className="text-lg font-bold text-gray-800">Login Minggu Ini</h3>
                    <p className="text-sm text-gray-500">Total {ownerData?.loginThisWeek || 0} login dalam 7 hari terakhir</p>
                  </div>
                </div>
                <button
                  onClick={() => setShowWeeklyLoginDetail(false)}
                  className="w-8 h-8 rounded-full bg-gray-100 hover:bg-gray-200 flex items-center justify-center transition"
                >
                  <X size={18} className="text-gray-500" />
                </button>
              </div>

              <div className="overflow-y-auto flex-1">
                <div className="space-y-3">
                  {ownerData?.recentLogins?.length > 0 ? (
                    ownerData.recentLogins.map((login: any, index: number) => (
                      <div key={index} className="p-3 bg-[#F9F6F3] rounded-xl border border-gray-100">
                        <div className="flex items-start gap-3">
                          <div className={`w-8 h-8 rounded-full flex items-center justify-center text-white text-xs font-bold ${
                            login.is_online ? 'bg-green-500' : 'bg-gray-400'
                          }`}>
                            {login.user_name?.charAt(0).toUpperCase() || '?'}
                          </div>
                          <div className="flex-1 min-w-0">
                            <div className="flex items-center gap-2 flex-wrap">
                              <span className="font-semibold text-gray-800 text-sm">{login.user_name}</span>
                              <span className={`px-1.5 py-0.5 text-xs font-medium rounded ${
                                login.user_role === 'owner' ? 'bg-[#8B5E3C]/20 text-[#8B5E3C]' :
                                login.user_role === 'supervisor' ? 'bg-blue-100 text-blue-700' :
                                login.user_role === 'bar' ? 'bg-purple-100 text-purple-700' :
                                'bg-orange-100 text-orange-700'
                              }`}>
                                {login.user_role}
                              </span>
                              {login.is_online && (
                                <span className="px-1.5 py-0.5 text-xs font-medium rounded bg-green-100 text-green-700">
                                  Online
                                </span>
                              )}
                            </div>
                            <div className="flex items-center gap-3 mt-1 text-xs text-gray-500">
                              <span className="flex items-center gap-1">
                                {login.device_type === 'mobile' ? (
                                  <Smartphone className="w-3 h-3" />
                                ) : (
                                  <Monitor className="w-3 h-3" />
                                )}
                                {login.device_type}
                              </span>
                              <span className="flex items-center gap-1">
                                <Globe className="w-3 h-3" />
                                {login.browser}
                              </span>
                              <span>{login.platform}</span>
                            </div>
                            <div className="flex items-center gap-4 mt-1 text-xs">
                              <span className="text-green-600 flex items-center gap-1">
                                <LogIn className="w-3 h-3" />
                                {new Date(login.login_at).toLocaleString('id-ID', {
                                  day: 'numeric', month: 'short',
                                  hour: '2-digit', minute: '2-digit'
                                })}
                              </span>
                              {login.logout_at && (
                                <span className="text-red-600 flex items-center gap-1">
                                  <LogOut className="w-3 h-3" />
                                  {new Date(login.logout_at).toLocaleString('id-ID', {
                                    day: 'numeric', month: 'short',
                                    hour: '2-digit', minute: '2-digit'
                                  })}
                                </span>
                              )}
                            </div>
                            <p className="text-xs text-gray-400 mt-1">IP: {login.ip_address}</p>
                          </div>
                        </div>
                      </div>
                    ))
                  ) : (
                    <div className="text-center py-8 text-gray-500">
                      <LogIn size={32} className="mx-auto mb-2 text-gray-300" />
                      <p>Belum ada login minggu ini</p>
                    </div>
                  )}
                </div>
              </div>

              <div className="flex gap-3 mt-4 pt-4 border-t border-gray-100">
                <button
                  onClick={() => setShowWeeklyLoginDetail(false)}
                  className="w-full bg-[#8B5E3C] text-white py-2.5 rounded-lg hover:bg-[#7A5235] font-semibold transition"
                >
                  Tutup
                </button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* MODAL DETAIL SUPERVISOR */}
      <AnimatePresence>
        {showSupervisorDetail && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center z-50 p-4"
          >
            <motion.div
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              className="bg-white rounded-2xl p-6 w-full max-w-2xl shadow-xl max-h-[80vh] overflow-hidden flex flex-col"
            >
              <div className="flex items-center justify-between mb-4">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 bg-[#8B5E3C] rounded-xl flex items-center justify-center">
                    <UserCog size={20} className="text-white" />
                  </div>
                  <div>
                    <h3 className="text-lg font-bold text-gray-800">Daftar Supervisor</h3>
                    <p className="text-sm text-gray-500">Total {ownerData?.totalSupervisor || 0} supervisor aktif</p>
                  </div>
                </div>
                <button
                  onClick={() => setShowSupervisorDetail(false)}
                  className="w-8 h-8 rounded-full bg-gray-100 hover:bg-gray-200 flex items-center justify-center transition"
                >
                  <X size={18} className="text-gray-500" />
                </button>
              </div>

              <div className="overflow-y-auto flex-1">
                <div className="space-y-3">
                  {ownerData?.supervisorList?.length > 0 ? (
                    ownerData.supervisorList.map((supervisor: any, index: number) => (
                      <div key={index} className="p-4 bg-[#F9F6F3] rounded-xl border border-gray-100">
                        <div className="flex items-start gap-3">
                          <div className="w-10 h-10 rounded-full bg-blue-500 flex items-center justify-center text-white font-bold">
                            {supervisor.name?.charAt(0).toUpperCase() || '?'}
                          </div>
                          <div className="flex-1 min-w-0">
                            <div className="flex items-center gap-2 flex-wrap">
                              <span className="font-semibold text-gray-800">{supervisor.name}</span>
                              <span className="px-1.5 py-0.5 text-xs font-medium rounded bg-blue-100 text-blue-700">
                                Supervisor
                              </span>
                            </div>
                            <p className="text-sm text-gray-500 mt-1">@{supervisor.username || '-'}</p>
                            <p className="text-sm text-gray-500">{supervisor.email}</p>
                            <p className="text-xs text-gray-400 mt-2">
                              Bergabung: {new Date(supervisor.created_at).toLocaleDateString('id-ID', {
                                day: 'numeric', month: 'long', year: 'numeric'
                              })}
                            </p>
                          </div>
                        </div>
                      </div>
                    ))
                  ) : (
                    <div className="text-center py-8 text-gray-500">
                      <UserCog size={32} className="mx-auto mb-2 text-gray-300" />
                      <p>Belum ada supervisor terdaftar</p>
                    </div>
                  )}
                </div>
              </div>

              <div className="flex gap-3 mt-4 pt-4 border-t border-gray-100">
                <button
                  onClick={() => setShowSupervisorDetail(false)}
                  className="w-full bg-[#8B5E3C] text-white py-2.5 rounded-lg hover:bg-[#7A5235] font-semibold transition"
                >
                  Tutup
                </button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* MODAL DETAIL IZIN DIPROSES */}
      <AnimatePresence>
        {showIzinProcessedDetail && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center z-50 p-4"
          >
            <motion.div
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              className="bg-white rounded-2xl p-6 w-full max-w-2xl shadow-xl max-h-[80vh] overflow-hidden flex flex-col"
            >
              <div className="flex items-center justify-between mb-4">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 bg-[#8B5E3C] rounded-xl flex items-center justify-center">
                    <ShieldCheck size={20} className="text-white" />
                  </div>
                  <div>
                    <h3 className="text-lg font-bold text-gray-800">Izin Revisi Diproses</h3>
                    <p className="text-sm text-gray-500">Total {ownerData?.izinProcessedThisMonth || 0} izin diproses bulan ini</p>
                  </div>
                </div>
                <button
                  onClick={() => setShowIzinProcessedDetail(false)}
                  className="w-8 h-8 rounded-full bg-gray-100 hover:bg-gray-200 flex items-center justify-center transition"
                >
                  <X size={18} className="text-gray-500" />
                </button>
              </div>

              <div className="overflow-y-auto flex-1">
                <div className="space-y-3">
                  {ownerData?.izinProcessedList?.length > 0 ? (
                    ownerData.izinProcessedList.map((izin: any, index: number) => (
                      <div key={index} className="p-4 bg-[#F9F6F3] rounded-xl border border-gray-100">
                        <div className="flex items-start gap-3">
                          <div className={`w-10 h-10 rounded-full flex items-center justify-center text-white font-bold ${
                            izin.status === 'approved' ? 'bg-green-500' : 'bg-red-500'
                          }`}>
                            {izin.status === 'approved' ? (
                              <CheckCircle2 size={20} />
                            ) : (
                              <XCircle size={20} />
                            )}
                          </div>
                          <div className="flex-1 min-w-0">
                            <div className="flex items-center gap-2 flex-wrap">
                              <span className="font-semibold text-gray-800">{izin.user_name}</span>
                              <span className={`px-1.5 py-0.5 text-xs font-medium rounded ${
                                izin.user_role === 'bar' ? 'bg-purple-100 text-purple-700' :
                                'bg-orange-100 text-orange-700'
                              }`}>
                                {izin.user_role}
                              </span>
                              <span className={`px-2 py-0.5 text-xs font-medium rounded ${
                                izin.status === 'approved'
                                  ? 'bg-green-100 text-green-700'
                                  : 'bg-red-100 text-red-700'
                              }`}>
                                {izin.status === 'approved' ? 'Disetujui' : 'Ditolak'}
                              </span>
                            </div>
                            {izin.reason && (
                              <p className="text-sm text-gray-600 mt-1">{izin.reason}</p>
                            )}
                            {izin.start_time && izin.end_time && (
                              <p className="text-xs text-gray-500 mt-1">
                                Waktu: {new Date(izin.start_time).toLocaleString('id-ID', {
                                  day: 'numeric', month: 'short',
                                  hour: '2-digit', minute: '2-digit'
                                })} - {new Date(izin.end_time).toLocaleString('id-ID', {
                                  hour: '2-digit', minute: '2-digit'
                                })}
                              </p>
                            )}
                            <p className="text-xs text-gray-400 mt-1">
                              Diproses: {new Date(izin.updated_at).toLocaleDateString('id-ID', {
                                day: 'numeric', month: 'long', year: 'numeric',
                                hour: '2-digit', minute: '2-digit'
                              })}
                            </p>
                          </div>
                        </div>
                      </div>
                    ))
                  ) : (
                    <div className="text-center py-8 text-gray-500">
                      <ShieldCheck size={32} className="mx-auto mb-2 text-gray-300" />
                      <p>Belum ada izin diproses bulan ini</p>
                    </div>
                  )}
                </div>
              </div>

              <div className="flex gap-3 mt-4 pt-4 border-t border-gray-100">
                <button
                  onClick={() => setShowIzinProcessedDetail(false)}
                  className="w-full bg-[#8B5E3C] text-white py-2.5 rounded-lg hover:bg-[#7A5235] font-semibold transition"
                >
                  Tutup
                </button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

{/* MODAL BARU: RINCIAN NAMA ITEM */}
      <AnimatePresence>
        {showItemDetailModal && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center z-[60] p-4"
          >
            <motion.div
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              className="bg-white rounded-2xl w-full max-w-lg shadow-2xl overflow-hidden flex flex-col max-h-[85vh]"
            >
              {/* Header Modal */}
              <div className="p-5 border-b border-gray-100 flex justify-between items-center bg-gray-50">
                <div>
                  <h3 className="text-lg font-bold text-gray-800">Rincian Item Stok</h3>
                  <p className="text-xs text-gray-500">Lihat item berdasarkan status stok</p>
                </div>
                <button
                  onClick={() => setShowItemDetailModal(false)}
                  className="p-2 hover:bg-gray-200 rounded-full transition text-gray-500"
                >
                  <X size={20} />
                </button>
              </div>

              {/* Tab Navigasi (Habis / Hampir / Aman) */}
              <div className="p-4 flex gap-2 border-b border-gray-100">
                <button
                  onClick={() => setSelectedDetailCategory('habis')}
                  className={`flex-1 py-2 rounded-lg text-xs font-bold transition flex items-center justify-center gap-2 ${
                    selectedDetailCategory === 'habis' ? 'bg-red-500 text-white shadow-md' : 'bg-red-50 text-red-600'
                  }`}
                >
                  <div className={`w-2 h-2 rounded-full ${selectedDetailCategory === 'habis' ? 'bg-white' : 'bg-red-500'}`} />
                  Habis ({
                    (itemDetails?.bar?.habis?.length || 0) + (itemDetails?.dapur?.habis?.length || 0)
                  })
                </button>
                <button
                  onClick={() => setSelectedDetailCategory('hampir')}
                  className={`flex-1 py-2 rounded-lg text-xs font-bold transition flex items-center justify-center gap-2 ${
                    selectedDetailCategory === 'hampir' ? 'bg-amber-500 text-white shadow-md' : 'bg-amber-50 text-amber-600'
                  }`}
                >
                  <div className={`w-2 h-2 rounded-full ${selectedDetailCategory === 'hampir' ? 'bg-white' : 'bg-amber-500'}`} />
                  Hampir ({
                    (itemDetails?.bar?.hampir?.length || 0) + (itemDetails?.dapur?.hampir?.length || 0)
                  })
                </button>
               <button
    onClick={() => setSelectedDetailCategory('aman')}
    className={`flex-1 py-2 rounded-lg text-xs sm:text-sm font-bold transition flex items-center justify-center gap-2 ${
      selectedDetailCategory === 'aman' ? 'bg-green-500 text-white shadow-md' : 'bg-green-50 text-green-600 hover:bg-green-100'
    }`}
  >
    <div className={`w-2 h-2 rounded-full ${selectedDetailCategory === 'aman' ? 'bg-white' : 'bg-green-500'}`} />

    {/* Ini bagian yang menampilkan jumlahnya */}
    Aman ({
      (itemDetails?.bar?.aman?.length || 0) + (itemDetails?.dapur?.aman?.length || 0)
    })
  </button>
              </div>

              {/* List Nama Item */}
              <div className="flex-1 overflow-y-auto p-4 space-y-6 bg-white">

                {/* LIST BAR */}
                {(isOwner || auth.user.role === 'bar' || auth.user.role === 'supervisor') && (
                  <div>
                    <h4 className="text-xs font-bold text-gray-400 uppercase tracking-wider mb-2 flex items-center gap-2">
                      <span className="w-2 h-2 rounded-full bg-[#8B5E3C]"></span> Divisi Bar
                    </h4>
                    <div className="space-y-2">
                      {itemDetails?.bar?.[selectedDetailCategory]?.length > 0 ? (
                        itemDetails.bar[selectedDetailCategory].map((item: any, idx: number) => (
                          <div key={idx} className="flex justify-between items-center p-3 bg-gray-50 border border-gray-100 rounded-xl hover:bg-gray-100 transition">
                            <span className="text-sm font-medium text-gray-700">{item.nama}</span>
                            <span className={`text-xs font-bold px-2 py-1 rounded-md ${
                              selectedDetailCategory === 'habis' ? 'bg-red-100 text-red-600' :
                              selectedDetailCategory === 'hampir' ? 'bg-amber-100 text-amber-600' :
                              'bg-green-100 text-green-600'
                            }`}>
                              Sisa: {item.stok}
                            </span>
                          </div>
                        ))
                      ) : (
                        <p className="text-xs text-gray-400 italic pl-4">Tidak ada item di kategori ini.</p>
                      )}
                    </div>
                  </div>
                )}

                {/* LIST DAPUR */}
                {(isOwner || ['dapur', 'kitchen', 'staff_kitchen'].includes(auth.user.role) || auth.user.role === 'supervisor') && (
                  <div>
                    <h4 className="text-xs font-bold text-gray-400 uppercase tracking-wider mb-2 mt-4 flex items-center gap-2">
                      <span className="w-2 h-2 rounded-full bg-[#D9A978]"></span> Divisi Dapur
                    </h4>
                    <div className="space-y-2">
                      {itemDetails?.dapur?.[selectedDetailCategory]?.length > 0 ? (
                        itemDetails.dapur[selectedDetailCategory].map((item: any, idx: number) => (
                          <div key={idx} className="flex justify-between items-center p-3 bg-gray-50 border border-gray-100 rounded-xl hover:bg-gray-100 transition">
                            <span className="text-sm font-medium text-gray-700">{item.nama}</span>
                            <span className={`text-xs font-bold px-2 py-1 rounded-md ${
                              selectedDetailCategory === 'habis' ? 'bg-red-100 text-red-600' :
                              selectedDetailCategory === 'hampir' ? 'bg-amber-100 text-amber-600' :
                              'bg-green-100 text-green-600'
                            }`}>
                              Sisa: {item.stok}
                            </span>
                          </div>
                        ))
                      ) : (
                        <p className="text-xs text-gray-400 italic pl-4">Tidak ada item di kategori ini.</p>
                      )}
                    </div>
                  </div>
                )}
              </div>

              {/* Footer: Tombol Shortcut */}
              <div className="p-4 bg-gray-50 border-t border-gray-100 grid grid-cols-2 gap-3">
                 <button onClick={() => router.visit('/stok-harian/bar')} className="py-2.5 rounded-xl border border-[#8B5E3C] text-[#8B5E3C] font-bold text-xs hover:bg-[#8B5E3C] hover:text-white transition">
                    Ke Stok Bar
                 </button>
                 <button onClick={() => router.visit('/stok-harian/dapur')} className="py-2.5 rounded-xl border border-[#8B5E3C] text-[#8B5E3C] font-bold text-xs hover:bg-[#8B5E3C] hover:text-white transition">
                    Ke Stok Dapur
                 </button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </AppLayout>


  );
}
