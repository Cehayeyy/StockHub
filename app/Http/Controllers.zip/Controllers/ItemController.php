<?php

namespace App\Http\Controllers;

use App\Models\Item;
use App\Models\ItemCategory;
use App\Models\ActivityLog;
use App\Models\Recipe;
use App\Models\StokHarianMenu;
use App\Models\StokHarianMentah;
use App\Models\StokHarianDapurMenu;
use App\Models\StokHarianDapurMentah;
use Illuminate\Http\Request;
use Inertia\Inertia;
use Inertia\Response;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;

class ItemController extends Controller
{
    public function index(Request $request): Response
    {
        $user = $request->user();

        if (in_array($user->role, ['bar', 'dapur'])) {
            $division = $user->role;
        } else {
            $division = $request->query('division', 'bar');
            if (!in_array($division, ['bar', 'dapur'])) {
                $division = 'bar';
            }
        }

        $category = strtolower($request->query('category', 'semua'));
        if (!in_array($category, ['semua', 'menu', 'mentah'])) {
            $category = 'semua';
        }

        $query = Item::with('itemCategory')
            ->where('items.division', $division);

        if ($request->search) {
            $query->where('items.nama', 'like', '%' . $request->search . '%');
        }

        if ($category === 'mentah') {
            $query->where(function ($q) {
                $q->whereHas('itemCategory', function ($cq) {
                    $cq->whereIn(DB::raw('LOWER(name)'), ['mentah', 'raw']);
                })->orWhereIn(DB::raw('LOWER(items.kategori_item)'), ['mentah', 'raw']);
            });
        } elseif ($category === 'menu') {
            $query->where(function ($q) {
                $q->whereHas('itemCategory', function ($cq) {
                    $cq->whereIn(DB::raw('LOWER(name)'), ['menu', 'finish']);
                })->orWhereIn(DB::raw('LOWER(items.kategori_item)'), ['menu', 'finish']);
            });
        }

        // Susun rapi dari Mentah lalu ke Menu, kemudian nama ASC
        $items = $query->leftJoin('item_categories', 'items.item_category_id', '=', 'item_categories.id')
            ->select('items.*')
            ->orderByRaw("
                CASE
                    WHEN LOWER(COALESCE(item_categories.name, items.kategori_item, '')) IN ('mentah', 'raw') THEN 1
                    WHEN LOWER(COALESCE(item_categories.name, items.kategori_item, '')) IN ('menu', 'finish') THEN 2
                    ELSE 3
                END ASC
            ")
            ->orderBy('items.nama', 'asc')
            ->paginate(10)
            ->withQueryString();

        $categories = ItemCategory::where('division', $division)
            ->orderBy('name')
            ->get(['id', 'name']);

        return Inertia::render('MasterData/Item', [
            'division'   => $division,
            'category'   => $category,
            'items'      => $items,
            'categories' => $categories,
            'search'     => $request->search,
        ]);
    }

    public function kategoriIndex(Request $request): Response
    {
        $division = $request->query('division', 'bar');

        if (!in_array($division, ['bar', 'dapur'])) {
            $division = 'bar';
        }

        $categories = ItemCategory::where('division', $division)
            ->orderBy('name')
            ->get()
            ->map(function (ItemCategory $cat) use ($division) {
                $items = $cat->items()
                    ->where('division', $division)
                    ->orderBy('nama')
                    ->get(['id', 'nama']);

                return [
                    'id'          => $cat->id,
                    'name'        => $cat->name,
                    'division'    => $cat->division,
                    'total_items' => $items->count(),
                    'items'       => $items,
                ];
            });

        return Inertia::render('MasterData/Kategori', [
            'division'   => $division,
            'categories' => $categories,
        ]);
    }

    public function kategoriStore(Request $request)
    {
        $data = $request->validate([
            'name'     => 'required|string|max:100',
            'division' => 'required|in:bar,dapur',
        ]);

        $exists = ItemCategory::where('division', $data['division'])
            ->where('name', $data['name'])
            ->exists();

        if ($exists) {
            return back()->with('error', 'Kategori sudah ada untuk divisi ini.');
        }

        $cat = ItemCategory::create($data);

        ActivityLog::create([
            'user_id'     => Auth::id(),
            'activity'    => 'Tambah Kategori',
            'description' => "Menambahkan kategori baru: '{$cat->name}' ({$cat->division})."
        ]);

        return redirect()
            ->route('kategori', ['division' => $data['division']])
            ->with('success', 'Kategori berhasil ditambahkan!');
    }

    public function kategoriUpdate(Request $request, ItemCategory $itemCategory)
    {
        $data = $request->validate([
            'name' => 'required|string|max:100',
        ]);

        $exists = ItemCategory::where('division', $itemCategory->division)
            ->where('name', $data['name'])
            ->whereKeyNot($itemCategory->id)
            ->exists();

        if ($exists) {
            return back()->with('error', 'Kategori sudah ada untuk divisi ini.');
        }

        $oldName = $itemCategory->name;

        DB::transaction(function () use ($itemCategory, $data, $oldName) {
            $itemCategory->update(['name' => $data['name']]);

            Item::where('item_category_id', $itemCategory->id)
                ->update(['kategori_item' => $data['name']]);

            ActivityLog::create([
                'user_id'     => Auth::id(),
                'activity'    => 'Update Kategori',
                'description' => "Mengupdate kategori dari '{$oldName}' menjadi '{$data['name']}'.",
            ]);
        });

        return redirect()
            ->route('kategori', ['division' => $itemCategory->division])
            ->with('success', 'Kategori berhasil diupdate!');
    }

    private function isCategoryMentah(string $categoryName): bool
    {
        $lower = strtolower(trim($categoryName));
        return in_array($lower, ['mentah', 'raw']);
    }

    public function store(Request $request)
    {
        $categoryId = $request->input('item_category_id');
        $category = $categoryId ? ItemCategory::find($categoryId) : null;
        $isMentah = $category && $this->isCategoryMentah($category->name);

        $data = $request->validate([
            'nama'             => 'required|string|max:255',
            'item_category_id' => 'required|exists:item_categories,id',
            'division'         => 'required|in:bar,dapur',
            'satuan'           => 'nullable|string|max:50',
            'harga_dasar'      => $isMentah ? 'required|numeric|min:0' : 'nullable',
        ], [
            'harga_dasar.required' => 'Harga dasar wajib diisi untuk kategori Mentah.',
            'harga_dasar.numeric'  => 'Harga dasar harus berupa angka.',
            'harga_dasar.min'      => 'Harga dasar tidak boleh kurang dari 0.',
        ]);

        $category = ItemCategory::findOrFail($data['item_category_id']);
        if ($category->division !== $data['division']) {
            return back()->with('error', 'Kategori tidak sesuai dengan divisi.');
        }

        if (empty($data['satuan'])) {
            $data['satuan'] = 'porsi';
        }

        $data['kategori_item'] = $category->name;

        // Pastikan hanya kategori Mentah yang menyimpan harga_dasar
        if (!$this->isCategoryMentah($category->name)) {
            $data['harga_dasar'] = null;
        }

        $item = Item::create($data);

        ActivityLog::create([
            'user_id'     => Auth::id(),
            'activity'    => 'Tambah Item',
            'description' => "Menambahkan item master baru: '{$item->nama}' ({$item->division})."
        ]);

        return back()->with('success', 'Item berhasil diupdate!');
    }

    public function update(Request $request, Item $item)
    {
        $categoryId = $request->input('item_category_id');
        $category = $categoryId ? ItemCategory::find($categoryId) : null;
        $isMentah = $category && $this->isCategoryMentah($category->name);

        $data = $request->validate([
            'nama'             => 'required|string|max:255',
            'item_category_id' => 'required|exists:item_categories,id',
            'division'         => 'required|in:bar,dapur',
            'satuan'           => 'nullable|string|max:50',
            'harga_dasar'      => $isMentah ? 'required|numeric|min:0' : 'nullable',
        ], [
            'harga_dasar.required' => 'Harga dasar wajib diisi untuk kategori Mentah.',
            'harga_dasar.numeric'  => 'Harga dasar harus berupa angka.',
            'harga_dasar.min'      => 'Harga dasar tidak boleh kurang dari 0.',
        ]);

        $category = ItemCategory::findOrFail($data['item_category_id']);
        if ($category->division !== $data['division']) {
            return back()->with('error', 'Kategori tidak sesuai dengan divisi.');
        }

        if (empty($data['satuan'])) {
            $data['satuan'] = 'porsi';
        }

        $data['kategori_item'] = $category->name;

        // Jika kategori diubah dari Mentah ke Menu/Finish/Semi Finish, set harga_dasar = null
        if (!$this->isCategoryMentah($category->name)) {
            $data['harga_dasar'] = null;
        }

        $oldName = $item->nama;

        $item->update($data);

        ActivityLog::create([
            'user_id'     => Auth::id(),
            'activity'    => 'Update Item',
            'description' => "Mengupdate data item dari '{$oldName}' menjadi '{$item->nama}'."
        ]);

        return back()->with('success', 'Item berhasil ditambahkan!');
    }

    // --- FUNGSI DESTROY YANG DIPERBAIKI ---
    public function destroy($id)
    {
        $item = Item::findOrFail($id);
        $division = $item->division;
        $name = $item->nama;

        DB::transaction(function () use ($item, $name) {
            // 1. Hapus Relasi Resep (Jika ada)
            $relatedRecipes = Recipe::where('name', $item->nama)
                                    ->orWhere('item_id', $item->id)
                                    ->get();

            foreach ($relatedRecipes as $recipe) {
                // Hapus Stok Dapur Menu (Pakai recipe_id)
                StokHarianDapurMenu::where('recipe_id', $recipe->id)->delete();
                $recipe->delete();
            }

            // 2. Hapus Stok Harian yang terhubung via ITEM_ID (Direct Link)
            // Ini menangani Bar Menu & Bar Mentah & Dapur Mentah

            // Bar Mentah
            StokHarianMentah::where('item_id', $item->id)->delete();

            // Bar Menu (Tabel stok_harian_menu pakai item_id)
            StokHarianMenu::where('item_id', $item->id)->delete();

            // 🔥 Dapur Mentah (INI YANG DITAMBAHKAN)
            StokHarianDapurMentah::where('item_id', $item->id)->delete();

            // 3. Hapus Item Utama
            $item->delete();

            ActivityLog::create([
                'user_id'     => Auth::id(),
                'activity'    => 'Hapus Item',
                'description' => "Menghapus item master '{$name}' dan seluruh data terkait."
            ]);
        });

        return back()->with('success', 'Item berhasil dihapus!');
    }

    public function destroyCategory(ItemCategory $itemCategory)
    {
        $division = $itemCategory->division;
        $name = $itemCategory->name;

        Item::where('item_category_id', $itemCategory->id)
            ->update([
                'item_category_id' => null,
                'kategori_item' => null,
            ]);

        $itemCategory->delete();

        ActivityLog::create([
            'user_id'     => Auth::id(),
            'activity'    => 'Hapus Kategori',
            'description' => "Menghapus kategori '{$name}'."
        ]);

        return redirect()
            ->route('kategori', ['division' => $division])
            ->with('success', 'Kategori berhasil dihapus!');
    }
}
