<?php

if (!function_exists('activity_log')) {
    function activity_log($message, $data = [])
    {
        // sementara kosong
    }
}
